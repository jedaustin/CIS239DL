##!/bin/bash
#########################
#FUNCTIONS
#########################
#
#dialog functions
#
function dialog_message(){
dialog --title 'Message' --textbox "$*" 20 50
} 
function inititem(){
if [ $1 != "DC" ]; then
echo -n $1 | awk '{print toupper(substr($1,1,1)) tolower(substr($1,2))}'
else
echo -n $1  
fi
}
function dialog_yesno(){
dialog --title 'Message' --yesno "$*" 20 40
}
#
#Other functions
#
function inititem(){
if [ $1 != "DC" ]; then
echo -n $1 | awk '{print toupper(substr($1,1,1)) tolower(substr($1,2))}'
else
echo -n $1 
fi
}
function initcap() {
local loopcount=1
for variable in $*; do
	echo $(inititem $variable)
	#If the loopcount does not equal the last variable, then add a space
	if [ $loopcount -ne ${#*} ]; then 
		echo -n " "
	fi

	#Time to increment the loop counter
	((loopcount++))
done;
}
function sort_keys(){
for key in ${!State[@]}; do
	echo $key
done | sort -k1
}
function make_menulist(){ 
unset menulist; i=0
local -a state_key=$(sort_keys)
for key in ${state_key[@]}; do
 menulist[i++]=${State["$key"]}
 menulist[i++]=''

done 
}
function make_radiolist(){
unset radiolist; i=0
pair_count=0
local -a state_key=$(sort_keys)
for key in ${state_key[@]}; do
((pair_count))
 #radiolist[i++]=$pair_count
 radiolist[i++]="$key"
 radiolist[i++]=${State["$key"]}
 radiolist[i++]="off"
done
}
########################################
#End Functions
########################################